1:"$Sreact.fragment"
2:I[20194,["/_next/static/chunks/26761b7332e15f73.js","/_next/static/chunks/03eae7f1d3e85eda.js","/_next/static/chunks/2740b24393285965.js"],"default"]
3:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"nBFe5YOga0J7ifl7kmyvb","rsc":["$","$1","c",{"children":[["$","div",null,{"children":["$","$L2",null,{}]}],[["$","script","script-0",{"src":"/_next/static/chunks/2740b24393285965.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
