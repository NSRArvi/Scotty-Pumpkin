var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/bank-transfer/approve/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__39c365be._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/node_modules_next_f5199d09._.js")
R.c("server/chunks/_next-internal_server_app_api_bank-transfer_approve_[id]_route_actions_2c205538.js")
R.m(90332)
module.exports=R.m(90332).exports
