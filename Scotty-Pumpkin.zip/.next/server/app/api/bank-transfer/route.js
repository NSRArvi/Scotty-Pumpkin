var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/bank-transfer/route.js")
R.c("server/chunks/[root-of-the-server]__ad4eee98._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/node_modules_next_f5199d09._.js")
R.c("server/chunks/_next-internal_server_app_api_bank-transfer_route_actions_1477af37.js")
R.m(97157)
module.exports=R.m(97157).exports
