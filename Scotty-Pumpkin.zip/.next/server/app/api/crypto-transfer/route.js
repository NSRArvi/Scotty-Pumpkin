var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/crypto-transfer/route.js")
R.c("server/chunks/[root-of-the-server]__8b5972bc._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_crypto-transfer_route_actions_8bddb1bb.js")
R.m(36542)
module.exports=R.m(36542).exports
