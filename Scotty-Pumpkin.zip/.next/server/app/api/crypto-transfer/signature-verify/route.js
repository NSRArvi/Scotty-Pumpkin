var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/crypto-transfer/signature-verify/route.js")
R.c("server/chunks/[root-of-the-server]__c6e38938._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/ce889_server_app_api_crypto-transfer_signature-verify_route_actions_fb98c277.js")
R.m(93583)
module.exports=R.m(93583).exports
