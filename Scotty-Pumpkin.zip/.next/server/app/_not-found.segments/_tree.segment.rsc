:HL["/_next/static/chunks/d407ced8981501c2.css","style"]
:HL["/_next/static/chunks/4f61850814c2e345.css","style"]
0:{"buildId":"nBFe5YOga0J7ifl7kmyvb","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"/_not-found","paramType":null,"paramKey":"/_not-found","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
