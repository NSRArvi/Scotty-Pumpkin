1:"$Sreact.fragment"
2:I[92852,["/_next/static/chunks/26761b7332e15f73.js","/_next/static/chunks/03eae7f1d3e85eda.js"],"default"]
3:I[39756,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"default"]
4:I[37457,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"default"]
5:I[74164,["/_next/static/chunks/26761b7332e15f73.js","/_next/static/chunks/03eae7f1d3e85eda.js","/_next/static/chunks/f7232b20135fec6d.js"],"default"]
:HL["/_next/static/chunks/d407ced8981501c2.css","style"]
:HL["/_next/static/chunks/4f61850814c2e345.css","style"]
0:{"buildId":"nBFe5YOga0J7ifl7kmyvb","rsc":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/d407ced8981501c2.css","precedence":"next"}],["$","link","1",{"rel":"stylesheet","href":"/_next/static/chunks/4f61850814c2e345.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/26761b7332e15f73.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/03eae7f1d3e85eda.js","async":true}]],["$","html",null,{"lang":"en","children":["$","body",null,{"className":"inter_a96a2a1f-module__Z4sW7q__className min-h-screen text-white relative overflow-x-hidden antialiased","children":["$","$L2",null,{"children":["$","$L3",null,{"parallelRouterKey":"children","template":["$","$L4",null,{}],"notFound":[["$","$L5",null,{}],[]]}]}]}]}]]}],"loading":null,"isPartial":false}
