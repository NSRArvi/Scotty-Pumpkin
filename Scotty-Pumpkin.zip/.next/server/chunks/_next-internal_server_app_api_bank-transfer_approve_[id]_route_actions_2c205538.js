module.exports=[30840,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_bank-transfer_approve_%5Bid%5D_route_actions_2c205538.js.map