module.exports=[41686,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_ecosystem_spump-economic-engine_page_actions_214f03ca.js.map