module.exports=[16038,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_eco-financial_page_actions_73a5792d.js.map