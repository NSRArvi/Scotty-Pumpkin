module.exports=[19623,a=>{"use strict";var b=a.i(87924),c=a.i(38246),d=a.i(28166);function e(){return(0,b.jsxs)(b.Fragment,{children:[(0,b.jsx)("style",{children:`
        @keyframes sp-float {
          0%, 100% { transform: translateY(0px) rotate(-3deg); }
          50%       { transform: translateY(-18px) rotate(3deg); }
        }
        @keyframes sp-glow-pulse {
          0%, 100% { opacity: 0.5; text-shadow: 0 0 40px rgba(245,158,11,0.4), 0 0 80px rgba(245,158,11,0.2); }
          50%       { opacity: 1;   text-shadow: 0 0 60px rgba(245,158,11,0.9), 0 0 120px rgba(245,158,11,0.5), 0 0 200px rgba(245,158,11,0.2); }
        }
        @keyframes sp-star-twinkle {
          0%, 100% { opacity: 0.2; transform: scale(1); }
          50%       { opacity: 1;   transform: scale(1.4); }
        }
        @keyframes sp-fade-up {
          from { opacity: 0; transform: translateY(24px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        @keyframes sp-spin-slow {
          from { transform: rotate(0deg); }
          to   { transform: rotate(360deg); }
        }
        @keyframes sp-orbit {
          from { transform: rotate(0deg) translateX(110px) rotate(0deg); }
          to   { transform: rotate(360deg) translateX(110px) rotate(-360deg); }
        }
        @keyframes sp-orbit-rev {
          from { transform: rotate(0deg) translateX(75px) rotate(0deg); }
          to   { transform: rotate(-360deg) translateX(75px) rotate(360deg); }
        }
        @keyframes sp-progress {
          0%   { width: 0%; }
          60%  { width: 72%; }
          80%  { width: 78%; }
          100% { width: 82%; }
        }
        @keyframes sp-blink {
          0%, 100% { opacity: 1; }
          50%       { opacity: 0; }
        }
        @keyframes sp-wrench {
          0%, 100% { transform: rotate(-15deg); }
          50%       { transform: rotate(15deg); }
        }
      `}),(0,b.jsx)("section",{className:"bg-primary-bg",children:(0,b.jsx)(d.default,{children:(0,b.jsxs)("div",{className:"relative min-h-screen flex flex-col items-center justify-center px-4 overflow-hidden",children:[[{size:2,top:"8%",left:"12%",delay:"0s",duration:"2.8s"},{size:1,top:"15%",left:"78%",delay:"0.5s",duration:"3.5s"},{size:3,top:"22%",left:"45%",delay:"1s",duration:"2.2s"},{size:1,top:"35%",left:"5%",delay:"1.5s",duration:"4s"},{size:2,top:"55%",left:"90%",delay:"0.3s",duration:"3.1s"},{size:1,top:"70%",left:"25%",delay:"0.8s",duration:"2.6s"},{size:2,top:"80%",left:"65%",delay:"1.2s",duration:"3.8s"},{size:1,top:"90%",left:"40%",delay:"0.6s",duration:"2.4s"},{size:3,top:"5%",left:"55%",delay:"1.8s",duration:"3.3s"},{size:1,top:"45%",left:"95%",delay:"0.2s",duration:"4.2s"},{size:2,top:"62%",left:"3%",delay:"1.4s",duration:"2.9s"},{size:1,top:"28%",left:"88%",delay:"0.9s",duration:"3.6s"}].map((a,c)=>(0,b.jsx)("div",{className:"nf-star",style:{width:a.size,height:a.size,top:a.top,left:a.left,animation:`sp-star-twinkle ${a.duration} ${a.delay} ease-in-out infinite`}},c)),(0,b.jsx)("div",{className:"absolute top-1/4 left-1/4 w-96 h-96 rounded-full pointer-events-none",style:{background:"radial-gradient(circle, rgba(245,158,11,0.06) 0%, transparent 70%)"}}),(0,b.jsx)("div",{className:"absolute bottom-1/4 right-1/4 w-80 h-80 rounded-full pointer-events-none",style:{background:"radial-gradient(circle, rgba(168,85,247,0.07) 0%, transparent 70%)"}}),(0,b.jsxs)("div",{className:"relative z-10 flex flex-col items-center text-center max-w-2xl mx-auto space-y-8",children:[(0,b.jsxs)("div",{className:"relative flex items-center justify-center",style:{width:240,height:240,animation:"sp-fade-up 0.6s ease both"},children:[(0,b.jsx)("div",{className:"absolute inset-0 rounded-full pointer-events-none",style:{border:"1px dashed rgba(245,158,11,0.2)",animation:"sp-spin-slow 20s linear infinite"}}),(0,b.jsx)("div",{className:"absolute rounded-full pointer-events-none",style:{width:150,height:150,top:"50%",left:"50%",marginTop:-75,marginLeft:-75,border:"1px dashed rgba(168,85,247,0.15)",animation:"sp-spin-slow 14s linear infinite reverse"}}),(0,b.jsx)("div",{className:"absolute",style:{top:"50%",left:"50%",marginTop:-12,marginLeft:-12},children:(0,b.jsx)("div",{style:{animation:"sp-orbit 8s linear infinite"},children:(0,b.jsx)("span",{style:{fontSize:22},children:"🔧"})})}),(0,b.jsx)("div",{className:"absolute",style:{top:"50%",left:"50%",marginTop:-10,marginLeft:-10},children:(0,b.jsx)("div",{style:{animation:"sp-orbit-rev 5s linear infinite"},children:(0,b.jsx)("span",{style:{fontSize:16},children:"⚙️"})})}),(0,b.jsx)("div",{style:{fontSize:90,animation:"sp-float 5s ease-in-out infinite",filter:"drop-shadow(0 0 30px rgba(245,158,11,0.5))"},children:"🎃"})]}),(0,b.jsxs)("div",{className:"space-y-3",style:{animation:"sp-fade-up 0.7s ease 0.15s both"},children:[(0,b.jsxs)("div",{className:"flex items-center justify-center gap-3",children:[(0,b.jsx)("span",{className:"sp-wrench text-2xl",children:"🔧"}),(0,b.jsx)("h1",{className:"text-3xl sm:text-4xl md:text-5xl font-black  text-primary",children:"Coming Soon"}),(0,b.jsx)("span",{className:"sp-wrench text-2xl",style:{animationDelay:"0.6s"},children:"🔧"})]}),(0,b.jsx)("p",{className:"text-secondary/80 text-base md:text-lg leading-relaxed max-w-md mx-auto",children:"Something amazing is brewing! Get ready for an incredible experience. We'll be here very soon!"})]}),(0,b.jsx)("div",{style:{animation:"sp-fade-up 0.7s ease 0.25s both"},children:(0,b.jsxs)("div",{className:"inline-flex items-center gap-2 rounded-full px-4 py-2",style:{background:"rgba(245,158,11,0.1)",border:"1px solid rgba(245,158,11,0.3)"},children:[(0,b.jsx)("div",{className:"nf-status-dot"}),(0,b.jsx)("span",{className:"text-primary text-xs font-bold uppercase tracking-widest",children:"Live Very Soon"})]})}),(0,b.jsx)("div",{className:"nf-divider w-full",style:{animation:"sp-fade-up 0.7s ease 0.3s both"}}),(0,b.jsxs)("div",{className:"w-full space-y-3",style:{animation:"sp-fade-up 0.7s ease 0.35s both"},children:[(0,b.jsxs)("div",{className:"flex justify-between items-center",children:[(0,b.jsx)("span",{className:"text-secondary/80 text-xs font-semibold uppercase tracking-wider",children:"Launch Progress"}),(0,b.jsx)("span",{className:"text-primary text-xs font-black",children:"Almost there..."})]}),(0,b.jsx)("div",{className:"nf-progress-track",children:(0,b.jsx)("div",{className:"nf-progress-fill"})})]}),(0,b.jsx)("div",{className:"grid sm:grid-cols-3 gap-3 w-full",style:{animation:"sp-fade-up 0.7s ease 0.4s both"},children:[{icon:"🛒",label:"Marketplace",status:"Coming Soon"},{icon:"💎",label:"SPUMP Token",status:"Ready"},{icon:"🌐",label:"Web3 Payments",status:"In Progress"}].map(a=>(0,b.jsxs)("div",{className:"nf-card rounded-xl px-4 py-4 text-center space-y-1.5",children:[(0,b.jsx)("span",{className:"text-2xl",children:a.icon}),(0,b.jsx)("p",{className:"text-secondary/80 text-xs font-bold",children:a.label}),(0,b.jsx)("span",{className:"text-xs font-semibold px-2 py-0.5 rounded-full inline-block",style:"Ready"===a.status?{background:"rgba(74,222,128,0.1)",border:"1px solid rgba(74,222,128,0.3)",color:"#4ade80"}:"In Progress"===a.status?{background:"rgba(99,102,241,0.12)",border:"1px solid rgba(99,102,241,0.3)",color:"#a5b4fc"}:{background:"rgba(245,158,11,0.12)",border:"1px solid rgba(245,158,11,0.3)",color:"#fbbf24"},children:a.status})]},a.label))}),(0,b.jsxs)("div",{className:"flex flex-col sm:flex-row gap-3 w-full sm:w-auto",style:{animation:"sp-fade-up 0.7s ease 0.5s both"},children:[(0,b.jsx)(c.default,{href:"/contact",className:"nf-notify-btn px-8 py-3.5 rounded-xl font-bold text-base text-white text-center",children:"✉️ Contact Us"}),(0,b.jsx)(c.default,{href:"https://x.com/SpumpCoin",target:"_blank",rel:"noopener noreferrer",className:"nf-social-btn px-8 py-3.5 rounded-xl font-semibold text-base text-secondary text-center",children:"🐦 Follow for Updates"})]}),(0,b.jsx)("p",{className:"text-white/25 text-xs pb-4",style:{animation:"sp-fade-up 0.7s ease 0.6s both"},children:"support@scottypumpkin.com · Scotty Pumpkin Eco Market System"})]})]})})})]})}a.s(["default",()=>e])}];

//# sourceMappingURL=app_not-found_jsx_a2a42ea3._.js.map