module.exports=[62715,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_legal-pack_page_actions_768ce434.js.map