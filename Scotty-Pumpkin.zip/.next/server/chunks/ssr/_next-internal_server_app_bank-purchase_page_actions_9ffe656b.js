module.exports=[97694,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_bank-purchase_page_actions_9ffe656b.js.map