module.exports=[39010,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_regulatory-framework_page_actions_7f2907ef.js.map