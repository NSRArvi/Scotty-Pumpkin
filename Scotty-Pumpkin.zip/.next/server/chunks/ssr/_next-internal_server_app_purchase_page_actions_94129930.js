module.exports=[6003,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_purchase_page_actions_94129930.js.map