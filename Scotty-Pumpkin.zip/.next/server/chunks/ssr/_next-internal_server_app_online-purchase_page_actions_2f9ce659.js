module.exports=[97269,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_online-purchase_page_actions_2f9ce659.js.map