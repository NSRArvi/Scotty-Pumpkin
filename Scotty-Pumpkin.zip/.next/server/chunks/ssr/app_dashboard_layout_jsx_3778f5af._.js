module.exports=[40270,a=>{"use strict";var b=a.i(7997);function c({children:a}){return(0,b.jsx)("div",{className:"relative z-10 min-h-screen bg-[#0b1220] text-white",children:a})}a.s(["default",()=>c])}];

//# sourceMappingURL=app_dashboard_layout_jsx_3778f5af._.js.map