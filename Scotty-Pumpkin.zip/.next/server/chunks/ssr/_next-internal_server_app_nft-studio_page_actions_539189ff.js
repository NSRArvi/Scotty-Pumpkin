module.exports=[482,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_nft-studio_page_actions_539189ff.js.map