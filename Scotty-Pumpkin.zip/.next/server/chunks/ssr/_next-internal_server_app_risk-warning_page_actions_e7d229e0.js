module.exports=[26434,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_risk-warning_page_actions_e7d229e0.js.map