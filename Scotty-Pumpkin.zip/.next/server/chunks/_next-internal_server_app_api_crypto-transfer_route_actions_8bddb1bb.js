module.exports=[55848,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_crypto-transfer_route_actions_8bddb1bb.js.map