module.exports=[73263,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_bank-transfer_route_actions_1477af37.js.map